var bg, bgImg, shooter, shooterImg, shooterShoting, shooterShotingImg
var zombie, zombieImg, zombieWalkerImg, zombieGroup,zombieIndex=-1;
var bullets, bulletsImg, bulletsGroup;
var heart1, heart2,heart3;
var heart1Img, heart2Img, heart3Img;
var gameOver, gameOverImg

var life = 3;
var bulletos = 5;
var reloading = false;
var gameState = PLAY;
var PLAY =1;
var END =0;
var i;
var j;


function preload(){
  bgImg = loadImage("floresta.png");
  shooterImg = loadImage("shooter_2.png"); 
  shooterShotingImg = loadImage("shooter_3.png");  
  zombieWalkerImg = loadAnimation("Walk1.png","Walk2.png","Walk3.png","Walk44.png","Walk5.png","Walk6.png");
  bulletsImg = loadImage("Bullets.png");
  tiro = loadSound("tiro.mp3");
  heart1Img = loadImage("heart_1.png");
  heart2Img = loadImage("heart_2.png");
  heart3Img = loadImage("heart_3.png");
  gameOverImg = loadImage("gameOver.png")
}

function setup() {
 createCanvas(1300,650);
  
  //adicionando a imagem de fundo
  bg = createSprite(660,450,30,30);
  bg.addImage(bgImg);
  bg.scale = 0.5

  // adicionando jogador
  shooter = createSprite(180,450,30,30);
  shooter.addImage(shooterImg);
  shooter.scale = 0.4;

  console.log(bulletos);

  //sprite para representar as vidas
  heart1 = createSprite(1000,40,20,20);
  heart1.visible = false;
  heart1.addImage("heart1",heart1Img);
  heart1.scale = 0.4;

  heart2 = createSprite(950,40,20,20);
  heart2.visible = false;
  heart2.addImage("heart2",heart2Img);
  heart1.scale = 0.4;

  heart3 = createSprite(1000,40,20,20);
  heart3.addImage("heart3",heart3Img);
  heart3.scale = 0.4;

  gameOver = createSprite(600,300,30,30);
  gameOver.scale = 1.0
  gameOver.addImage(gameOverImg);
  gameOver.visible = false;


  //criando grupo dos zumbis
  zombieGroup = new Group();
  bulletsGroup = new Group();

}

function draw() {
  background(0);
  text("carregando",200,200);
    //mover jogador para baixo 
  if (keyDown("S") && shooter.y < 600){
    shooter.y +=10;

  }
  // mover jogador para cima
  if (keyDown("W") && shooter.y > 60){
    shooter.y -=10;
  }

  // mover jogador para direita
  if (keyDown("D") && shooter.x < 1250){
    shooter.x +=10;
  }
  // mover jogador para esquerda
  if (keyDown("A") && shooter.x > 12){
    shooter.x -=10;
  }



if (gameState === END) {
   gameOver.visible = true;
   textSize(30);
   text("aperte o botão para cima para recomeçar!",600,100);

  }

  //logica para exibir a imagem das vidas
  if (life == 3){
    heart3.visible = true;
    heart2.visible = false;
    heart1.visible = false;
   
  }

  if (life == 2){
    heart3.visible = false;
    heart2.visible = true;
    heart1.visible = false;
  }

  if (life == 1){
    heart3.visible = false;
    heart2.visible = false;
    heart1.visible = true;
  }

  if (life == 0){
    heart3.visible = false;
    heart2.visible = false;
    heart1.visible = false;
    shooter.destroy();
    gameState = 0;
  }
  
  for(var j=0;j<bulletsGroup.lenght;j++){
    for(var i=0;i<zombieGroup.lenght;i++){
      if (bulletsGroup[j].isTouching(zombieGroup[i])){
        bulletsGroup[j].destroy();
        zombieGroup[i].destroy();
        break;
      }
    }
  }

  if(zombieIndex!==-1){
    zombieGroup[zombieIndex].destroy();
  }
  

  if (keyWentDown("SPACE") && bulletos > 0){
    bullets = createSprite(shooter.x+60,shooter.y-30,20,10)
    bullets.addImage(bulletsImg);
    bullets.scale = 0.1;
    bullets.velocityX =20;
    shooter.addImage(shooterShotingImg);
    bulletos = bulletos -1;
    bulletsGroup.add(bullets);
    tiro.play();
  }

else if(keyWentUp("SPACE")){
  shooter.addImage(shooterImg);
  
  }

  if (keyWentDown("E") && bulletos < 5) {
    reloading = true;
    reloadTime = 30; 
   
    // 2 segundos (60 frames por segundo)
  }
  
  if (reloading) {
    reloadTime--;
    
    if (reloadTime <= 0) {
      bulletos = 2;
      reloading = false;
    }
  }
  
  //destruir o zombie quando jogador tocar nele
  if(zombieGroup.isTouching(shooter)){
    for (var i=0;i<zombieGroup.length;i++){
      if(zombieGroup[i].isTouching(shooter)){
        zombieGroup[i].destroy();
        life--;
      }
    }
  }
  

  spawEnemy();
  drawSprites(); 
  

}

 //adicionando zumbis aleatorios
function spawEnemy(){
  if (frameCount % 150 == 0){
    var zombie = createSprite(1400,random(180,450),40,40);
    zombie.addAnimation("Walk",zombieWalkerImg);
    zombie.velocityX =-1;
    zombie.scale = 0.5;
    zombie.lifetime = 1900;
    zombieGroup.add(zombie);
  }


}



